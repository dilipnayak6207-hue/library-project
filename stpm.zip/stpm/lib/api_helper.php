<?php
// lib/api_helper.php

define('AWS_API', 'https://mfxyu9hvjf.execute-api.us-east-1.amazonaws.com/dev/');

function callSalesAPI(array $payload,$funName)
{
    $ch = curl_init(AWS_API.$funName);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json'
        ],
        CURLOPT_TIMEOUT        => 10
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return [
            "error" => "API connection failed",
            "details" => curl_error($ch)
        ];
    }

    curl_close($ch);

    $data = json_decode($response, true);

    // Safety check
    if (!isset($data['body'])) {
        return ["error" => "Invalid API response"];
    }

    return json_decode($data['body'], true);
}
