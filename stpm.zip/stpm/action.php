<?php
session_start();
include("config/db.php");


if($_POST){
  //echo "<pre>";print_r($_POST);exit;

    $email=$_POST['email'];
    $password=$_POST['pass'];

    //SQL Query
    $sql="SELECT id,name,email,status FROM users WHERE 
    email='$email' AND password='$password' AND status='0' ";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $users = $result->fetch_assoc();
        //echo "<pre>"; print_r($_SESSION);exit;

        //set session
        $_SESSION['user_id'] = $users['id'];
        $_SESSION['name'] = $users['name'];
        $_SESSION['email'] = $users['email'];
        $_SESSION['role'] = $users['role'];

        header("Location: dashboard.php");
        exit();
    }else{
        // echo"invalid email or password";
        header("location: login.php?invalidlogin=1");
        
    
    }
}

?>