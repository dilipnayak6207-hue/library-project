<?php
session_start();
include("config/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location:index.php");
    exit();
}

$username = $_SESSION['name'];
$session_id = $_SESSION['user_id'];

$sql = "SELECT teams.name AS Teamname,
               SUM(sales.amount) AS sales
        FROM sales
        JOIN teams ON sales.team_id = teams.id
        WHERE sales.user_id='$session_id'
        GROUP BY sales.team_id";

$result = $conn->query($sql);
$result1 = $conn->query($sql);
$result2 = $conn->query($sql);

$total_sales = 0;
$total_teams = 0;
$max_sales = 0;
$top_team = "";

while ($row = $result2->fetch_assoc()) {

    $total_sales += $row['sales'];
    $total_teams++;

    if ($row['sales'] > $max_sales) {
        $max_sales = $row['sales'];
        $top_team = $row['Teamname'];
    }
}

$average_sales = ($total_teams > 0)
    ? round($total_sales / $total_teams, 2)
    : 0;

$datastring = "";

if ($result1->num_rows > 0) {

    while ($row = $result1->fetch_assoc()) {

        $percentage = round(($row['sales'] / $total_sales) * 100);

        $datastring .= "{
            name:'" . $row['Teamname'] . "',
            y:" . $percentage . "
        },";
    }
}

$datastring = rtrim($datastring, ",");

?>

<!DOCTYPE html>
<html>

<head>
    <title>Sales Dashboard</title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>

    <style>
        body {
            background: #f4f6f9;
        }

        .dashboard-header {
            background: #0d6efd;
            color: white;
            padding: 20px;
            border-radius: 10px;
        }

        .summary-card {
            color: white;
            border: none;
            border-radius: 10px;
        }

        .chart-card {
            min-height: 450px;
        }
    </style>
</head>

<body>

    <div class="container-fluid p-4">

        <!-- HEADER -->

        <div class="dashboard-header mb-4">
            <div class="d-flex justify-content-between align-items-center">

                <h2>Dashboard</h2>

                <div>
                    <span class="fw-bold me-3">
                        <?php echo $username; ?>
                    </span>

                    <a href="logout.php" class="btn btn-warning">
                       🚪 Logout
                    </a>
                    <a href="sales_manage.php" class=" btn btn-warning active-menu">
                        📊Manage Sales
                    </a>
                    <!-- CLOUD BUTTON -->
                    <a href="/karmastrategies/stpm/lib/sales_manage.php" class="btn btn-warning active-menu">
                        ☁️ Go to Cloud Sales
                    </a>
                </div>

            </div>
        </div>

        <!-- SUMMARY CARDS -->

        <div class="row mb-4">

            <div class="col-md-3">
                <div class="card summary-card bg-success">
                    <div class="card-body">
                        <h3><?php echo $total_sales; ?></h3>
                        <h5>Total Sales</h5>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card summary-card bg-primary">
                    <div class="card-body">
                        <h3><?php echo $total_teams; ?></h3>
                        <h5>Total Teams</h5>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card summary-card bg-info">
                    <div class="card-body">
                        <h3>₹<?php echo $average_sales; ?></h3>
                        <h5>Average Sales</h5>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card summary-card bg-dark">
                    <div class="card-body">
                        <h3><?php echo $top_team; ?></h3>
                        <h5>Top Team</h5>
                    </div>
                </div>
            </div>

        </div>

        <!-- CHARTS -->

        <div class="row mb-4">

            <div class="col-md-4">
                <div class="card chart-card shadow">
                    <div class="card-body">
                        <div id="container1"></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card chart-card shadow">
                    <div class="card-body">
                        <div id="container"></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card chart-card shadow">
                    <div class="card-body">
                        <div id="container2"></div>
                    </div>
                </div>
            </div>

        </div>

        <!-- TABLE -->

        <div class="card shadow">

            <div class="card-header bg-primary text-white">
                Sales Records
            </div>

            <div class="card-body">

                <table class="table table-bordered table-striped text-center">

                    <thead class="table-dark">

                        <tr>
                            <th>Sl No</th>
                            <th>Team Name</th>
                            <th>Total Sales</th>
                            <th>Percentage</th>
                            <th>Performance</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php

                        $count = 1;

                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_assoc()) {

                                $performance = round(($row['sales'] / $total_sales) * 100);
                                ?>

                                <tr>

                                    <td><?php echo $count++; ?></td>

                                    <td><?php echo $row['Teamname']; ?></td>

                                    <td><?php echo $row['sales']; ?></td>

                                    <td><?php echo $performance; ?>%</td>

                                    <td>

                                        <?php

                                        if ($performance >= 60) {
                                            echo '<span class="badge bg-success">Excellent</span>';
                                        } elseif ($performance >= 40) {
                                            echo '<span class="badge bg-primary">Average</span>';
                                        } else {
                                            echo '<span class="badge bg-warning text-dark">Good</span>';
                                        }

                                        ?>

                                    </td>

                                </tr>

                                <?php
                            }
                        } else {
                            ?>

                            <tr>
                                <td colspan="5">No Records Found</td>
                            </tr>

                            <?php
                        }
                        ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

    <!-- BAR CHART -->

    <script>
        Highcharts.chart('container1', {
            chart: {
                type: 'bar'
            },
            title: {
                text: 'Sales Performance'
            },
            xAxis: {
                type: 'category'
            },
            yAxis: {
                title: {
                    text: 'Percentage (%)'
                }
            },
            series: [{
                colorByPoint: true,
                data: [<?php echo $datastring; ?>]
            }]
        });
    </script>

    <!-- PIE CHART -->

    <script>
        Highcharts.chart('container', {
            chart: {
                type: 'pie'
            },
            title: {
                text: 'Sales Share By Team'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    dataLabels: {
                        enabled: true,
                        format: '{point.name}<br>{point.y}%'
                    }
                }
            },
            series: [{
                name: 'Percentage',
                colorByPoint: true,
                size: '75%',   // Pie chart bada hoga
                data: [
                    <?php echo $datastring; ?>
                ]
            }]
        });
    </script>

    <!-- COLUMN CHART -->

    <script>
        Highcharts.chart('container2', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Team Wise Sales'
            },
            xAxis: {
                type: 'category'
            },
            yAxis: {
                title: {
                    text: 'Percentage (%)'
                }
            },
            series: [{
                colorByPoint: true,
                data: [<?php echo $datastring; ?>]
            }]
        });
    </script>

</body>

</html>