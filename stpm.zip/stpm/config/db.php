<?php 
$servername="localhost:3307";
$username="root";
$password="";
$dbname="sales_management";
//create connection
$conn=new mysqli("localhost:3307", "root","" ,"sales_management");

$local_base = "/stpm/";
$cloud_base = "/cloud/";
?>