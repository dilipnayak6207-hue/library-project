<?php
include("config/db.php");

$id = $_GET['id'];

$query = "SELECT * FROM sales WHERE id='$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {

    $teams = $_POST['teams'];
    $amount = $_POST['amount'];
    $sale_date = $_POST['sale_date'];

    $update = "UPDATE sales
               SET teams='$teams',
                   amount='$amount',
                   sale_date='$sale_date'
               WHERE id='$id'";

    if (mysqli_query($conn, $update)) {
        echo "<script>
                alert('Sales record updated successfully!');
                window.location='sales_manage.php';
              </script>";
    } else {
        echo "<script>
                alert('Update failed!');
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Sales</title>

    <!-- Bootstrap CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <div style="
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg,#4facfe,#00f2fe);
">

        <div class="card" style="
        background: #ffffff;
        border-radius: 20px;
        border: none;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        padding: 25px;
        width: 420px;
    ">

            <div class="header" style="
            text-align:center;
            font-size:20px;
            font-weight:bold;
            color:#4f46e5;
            margin-bottom:15px;
        ">
                <h3 class="mb-0">Edit Sales Record</h3>
            </div>


            <div class="card-body p-4">
                <form method="POST">

                    <!-- Team -->
                    <div class="mb-3">
                        <label class="form-label">Team</label>
                        <select name="teams" class="form-select" required>

                            <option value="Closing Crew" <?php if ($row['teams'] == 'Closing Crew')
                                echo 'selected'; ?>>
                                Closing Crew
                            </option>

                            <option value="Revenue Rocket" <?php if ($row['teams'] == 'Revenue Rocket')
                                echo 'selected'; ?>>
                                Revenue Rocket
                            </option>

                            <option value="Peak Performer" <?php if ($row['teams'] == 'Peak Performer')
                                echo 'selected'; ?>>
                                Peak Performer
                            </option>

                        </select>
                    </div>

                    <!-- Amount -->
                    <div class="mb-3">
                        <label class="form-label">Amount</label>
                        <input type="number" name="amount" class="form-control" value="<?php echo $row['amount']; ?>"
                            required>
                    </div>

                    <!-- Date -->
                    <div class="mb-4">
                        <label class="form-label">Date</label>
                        <input type="date" name="sale_date" class="form-control"
                            value="<?php echo $row['sale_date']; ?>" required>
                    </div>

                    <!-- Button -->
                    <div class="d-grid">
                        <button type="submit" name="update" class="btn btn-success">
                            Update Record
                        </button>
                    </div>

                </form>
            </div>

        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>