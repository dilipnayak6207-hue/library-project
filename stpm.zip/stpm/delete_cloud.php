<?php

include("lib/api_helper.php");

$id = $_GET['id'];

$response = callSalesAPI([
    "action" => "delete",
    "id" => $id
], 'sales_crud');

if(isset($response['success']) && $response['success'] == true)
{
    echo "<script>
        alert('Deleted Successfully');
        window.location='sales_manage_cloud.php';
    </script>";
}
else
{
    echo "<script>
        alert('Delete Failed');
        window.location='sales_manage_cloud.php';
    </script>";
}
?>