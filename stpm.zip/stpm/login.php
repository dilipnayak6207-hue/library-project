<?php
$message = "";
if (isset($_GET['invalidlogin']) && $_GET['invalidlogin'] == 1) {
    $message = 'Invalid Password';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Validation</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
    </style>
</head>

<body class="text-white"
    style="background-image: url('assets/images/sales.jpg'); background-size: cover; background-position: center;">

<!-- ===== BACKGROUND loginpage ===== -->
 <div class="d-flex justify-content-center mt-3">
 <div style="width:180px; height:180px; border-radius:50%; background-color:white;">
 <img src="assets/images/logo1.png" style="width: 180px; ">
</div>
 </div>

  <h2 class="text-center ">Sales Team Performance</h2>
<div style="
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100%;
    z-index:-1;
    opacity:0.25;
    background: linear-gradient(135deg,#0f172a,#1e293b);
    padding-top:10px;
">

    <div class="container text-white">
       

       

        <div class="row text-center">

            <!-- Bar Chart -->
            <div class="col-md-4">
                <h6>Bar Chart</h6>
                <div style="height:200px; display:flex; align-items:flex-end; justify-content:space-around;">
                    <div style="width:20px;height:60%;background:#22c55e;"></div>
                    <div style="width:20px;height:80%;background:#3b82f6;"></div>
                    <div style="width:20px;height:50%;background:#f59e0b;"></div>
                    <div style="width:20px;height:90%;background:#ef4444;"></div>
                </div>
            </div>

            <!-- Column Chart -->
            <div class="col-md-4">
                <h6>Column Chart</h6>
                <div style="height:200px; display:flex; align-items:flex-end; justify-content:space-around;">
                    <div style="width:30px;height:70%;background:#60a5fa;"></div>
                    <div style="width:30px;height:40%;background:#34d399;"></div>
                    <div style="width:30px;height:90%;background:#f97316;"></div>
                </div>
            </div>

            <!-- Pie Chart -->
            <div class="col-md-4">
                <h6>Pie Chart</h6>
                <div style="
                    width:150px;
                    height:150px;
                    margin:auto;
                    border-radius:50%;
                    background: conic-gradient(
                        #22c55e 0% 40%,
                        #3b82f6 40% 70%,
                        #f59e0b 70% 100%
                    );
                "></div>
            </div>

        </div>
    </div>
</div>

<!-- ===== LOGIN SECTION ===== -->
<div class="container-fluid my-2">

   
    <div class="row justify-content-center">

        <div class="col-md-4">

            <div class="card text-white"
                style="background: rgba(0,0,0,0.6);
                       border: none;
                       backdrop-filter: blur(8px);
                       border-radius:15px;">

                <div class="card-body">

                    <?php if ($message != "") { ?>
                        <div class="text-center text-danger mb-3">
                            <?= $message ?>
                        </div>
                    <?php } ?>

                    <div class="text-center">
                        <h2>LOGIN</h2>
                    </div>

                    <form action="action.php" method="POST">

                        <div class="mb-3 mt-3">
                            <label class="form-label">Email:</label>

                            <input type="email"
                                class="form-control"
                                placeholder="Enter your email"
                                name="email"
                                required>

                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password:</label>

                            <input type="password"
                                class="form-control"
                                placeholder="Enter your password"
                                name="pass"
                                required>

                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-danger">
                                Sign In
                            </button>
                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>