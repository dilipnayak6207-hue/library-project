<?php
include 'lib/api_helper.php';
session_start();

$username = $_SESSION['name'];
//print_r($_POST);exit;
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$teams = callSalesAPI(["action" => "getTeams"], 'sales_crud');
//echo "<pre>";print_r($teams);exit;

if ($_POST) {

    $res=callSalesAPI([
        "action" => ($_POST['id'] == "" ? "add" : "update"),
        "user_id" => $_SESSION['user_id'],
        "id" => $_POST['id'] ?? null,
        "team_id" => $_POST['team_id'],
        "amount" => $_POST['amount'],
        "sale_date" => $_POST['sale_date']
    ], 'sales_crud');
    //print_r($res);exit;
    echo "<script>
        alert('Saved Successfully');
        window.location='sales_manage_cloud.php';
    </script>";
}


$data = callSalesAPI([
    "action" => "list"
], 'sales_crud');
//echo "<pre>";print_r($data);exit;
?>

<!DOCTYPE html>
<html>

<head>
    <title>Sales Management</title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial;
        }

        /* SIDEBAR */
        .sidebar {
            width: 220px;
            height: 100vh;
            position: fixed;
            background: linear-gradient(180deg, #0d6efd, #6610f2);
            color: white;
            padding-top: 20px;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
        }

        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        /* CONTENT */
        .content {
            margin-left: 220px;
            padding: 20px;
        }

        /* HEADER */
        .header {
            background: linear-gradient(90deg, #0d6efd, #20c997);
            color: white;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        /* CARD */
        .card-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        /* TABLE */
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
        }

        th {
            background: #0d6efd;
            color: white;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        /* BUTTONS */
        .btn-edit {
            background: #ffc107;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .btn-delete {
            background: #dc3545;
            border: none;
            padding: 5px 10px;
            color: white;
            border-radius: 5px;
        }

        .btn-save {
            background: #198754;
            border: none;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
        }

        input,
        select {
            padding: 8px;
            margin: 5px;
            width: 99%;
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h4 style="padding: 30px 15px;
            text-align: center;
            color: white;
            font-weight: bold" ;>CLOUD SALES</h4>

        <div style="display: flex; justify-content: center; align-items: center; width: 100%;">

            <span class="fw-bold me-3"
                style="color: white; background-color: #007bff; padding: 10px 20px; border-radius: 5px; cursor: pointer; display: inline-block;">
                <?php echo $username; ?>
            </span>

        </div>
        <a href="/karmastrategies/stpm/dashboard.php" style="color:#ff4d4d;">
            🏠Dashboard
        </a>
        <a href="/karmastrategies/stpm/sales_manage.php">📊 Sales Manage</a>
        <a href="/karmastrategies/stpm/sales_manage_cloud.php" style="color:#ff4d4d;">
            ☁️ Cloud Manage sales
        </a>
        <a href="/karmastrategies/stpm/logout.php">🚪 Logout</a>

    </div>

    <!-- CONTENT -->
    <div class="content">

        <!-- HEADER -->
        <div class="header">
            <h2>Sales Management System</h2>
        </div>

        <!-- FORM -->
        <div class="card-box">

            <h3>Add Sale</h3>

            <form method="POST">

    <input type="hidden" value="">
                <select name="team_id" required>

                    <option value="">Select Team</option>
                    <?php foreach ($teams as $key => $value) { ?>
                        <option value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>
                    <?php } ?>
                </select>

                <input type="number" name="amount" placeholder="Amount" required>

                <input type="date" name="sale_date" required>

                <button class="btn-save">Save</button>

            </form>

        </div>

        <!-- TABLE -->
        <div class="card-box">

            <h3>Sales List</h3>

            <?php
            $teamMap = [
                "1" => "Closing Crew",
                "2" => "Peak Performer",
                "3" => "Revenue Rocket"
            ];
            ?>

            <table>

                <tr>
                    <th>ID</th>
                    <th>Team</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>

                <?php $i = 1;
                foreach ($data as $row) { ?>

                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $row['team']; ?></td>
                        <td><?= $row['amount'] ?></td>
                        <td><?= $row['sale_date'] ?></td>

                        <td>
                            <a href="sales_manage_cloud.php?id=<?= $row['id'] ?>">
                                <button type="button" class="btn-edit">Edit</button>
                            </a>

                            <a href="sales_manage_cloud.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this record?')">
                                <button type="button" class="btn-delete">Delete</button>
                            </a>
                        </td>
                    </tr>

                <?php } ?>

            </table>

        </div>

    </div>

</body>

</html>