<?php

include("lib/api_helper.php");

$id = $_GET['id'] ?? null;
print_r($_POST);exit;
// fetch single record
$row = callSalesAPI([
    "action" => "getOne",
    "id" => $id
], 'sales_crud');
$teams = callSalesAPI(["action" => "getTeams"], 'sales_crud');

$row = $row[0];

// update record
if (isset($_POST['edit'])) {

    $team_id = $_POST['teams'];
    $amount = $_POST['amount'];
    $sale_date = $_POST['sale_date'];

    callSalesAPI([
        "action" => "update",
        "id" => $id,
        "team_id" => $team_id,
        "amount" => $amount,
        "sale_date" => $sale_date
    ], 'sales_crud');

    echo "<script>
        alert('Updated Successfully');
        window.location='sales_manage_cloud.php';
    </script>";
    header("Location: sales_manage_cloud.php");
    exit;
}

?>
<div style="
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg,#4facfe,#00f2fe);
">

    <div class="card" style="
        background: #ffffff;
        border-radius: 20px;
        border: none;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        padding: 25px;
        width: 420px;
    ">

        <div class="header" style="
            text-align:center;
            font-size:20px;
            font-weight:bold;
            color:#4f46e5;
            margin-bottom:15px;
        ">
            Data Edit Operation
        </div>

        <form method="POST">

            <label style="font-weight:bold;">Team</label>
            <select name="teams" style="
                width:100%;
                padding:10px;
                margin:8px 0 15px 0;
                border-radius:10px;
                border:1px solid #ccc;
            ">
                <?php foreach ($teams as $key => $value) { ?>
                     <option value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>
               <?php } ?>

            </select>

            <label style="font-weight:bold;">Amount</label>
            <input type="number" name="amount" value="<?= $row['amount'] ?>" required style="
                width:100%;
                padding:10px;
                margin:8px 0 15px 0;
                border-radius:10px;
                border:1px solid #ccc;
            ">

            <label style="font-weight:bold;">Sale Date</label>
            <input type="date" name="sale_date" value="<?= $row['sale_date'] ?>" required style="
                width:100%;
                padding:10px;
                margin:8px 0 20px 0;
                border-radius:10px;
                border:1px solid #ccc;
            ">

            <button type="submit" name="edit" style="
                width:100%;
                padding:12px;
                background:#4f46e5;
                color:white;
                border:none;
                border-radius:10px;
                font-size:16px;
                cursor:pointer;
            ">
                Update
            </button>

        </form>

    </div>

</div>