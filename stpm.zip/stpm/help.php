<?php
// ✅ Include API helper
include 'lib/api_helper.php';
// Start session to access logged-in user data
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: index.php");
    exit();
}


// Fetch active teams from database (status = 0 means active)
    $teams = callSalesAPI(["action" => "getTeams"],'sales_crud');
     
     
// ---------------------- ADD or UPDATE ----------------------
if($_POST){
    callSalesAPI([
        "action" => ($_POST['id'] == "" ? "add" : "update"),
        "user_id" => $_SESSION['user_id'],
        "id" => $_POST['id'] ?? null,
        "team_id" => $_POST['team'],
        "amount" => $_POST['amount'],
        "sale_date" => $_POST['sale_date']
    ],'sales_crud');

    header("Location: sales.php");
}

// ---------------------- DELETE ----------------------
// Check if delete request is present in URL
if(isset($_GET['delete'])){
    callSalesAPI([
        "action" => "delete",
        "id" => $_GET['delete']
    ],'sales_crud');

    header("Location: sales.php");
}

// ---------------------- EDIT FETCH ----------------------
$editData = null;

// Check if edit request is present in URL
if(isset($_GET['edit'])){
    $editData = callSalesAPI([
        "action" => "getOne",
        "id" => $_GET['edit']
    ],'sales_crud');    
}
// ---------------------- FETCH ALL SALES ----------------------
$result = callSalesAPI([
    "action" => "list",
    "role" => $_SESSION['role'],
    "user_id" => $_SESSION['user_id']
],'sales_crud');

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Page title -->
    <title>STPM :: MANAGE SALES</title>

    <!-- Website icon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">

    <!-- Bootstrap CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/css/custom.css" rel="stylesheet"> 
    
</head>

<body>

<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <div class="col-md-2 sidebar">
            <h4>Dashboard</h4>

            <!-- Navigation links -->
            <a href="dashboard.php">Dashboard</a>
            <a href="sales.php">Manage Sales</a>
        </div>

        <!-- Main Content -->
        <div class="col-md-10 p-4">

            <!-- Header -->
            <div style="width:100%;">

                <!-- Page title -->
                <div style="float:left;">
                    <h2 class="mb-4">Sales Manage</h2>
                </div>

                <!-- User info and logout -->
                <div style="float:right;">
                    <div class="d-flex justify-content-end align-items-center gap-3 p-2 bg-light rounded shadow-sm">
    
                    <div class="text-end">
                        <div class="fw-bold text-primary">
                            <?php echo $_SESSION['name']; ?> 
                            <small class="text-muted">
                                (<?php echo ucfirst($_SESSION['role']); ?>)
                            </small>
                        </div>                        
                    </div>

                    <!-- Logout button -->
                    <a href="logout.php" class="btn btn-outline-danger btn-sm">
                        Logout
                    </a>

                </div>
                </div>
            </div>  

            <div style="clear:both;"></div>  

            <!-- ---------------------- FORM ---------------------- -->
            <div class="card p-4 mb-4 shadow">

                <!-- Dynamic heading (Add / Update) -->
                <h5><?= $editData ? "Update Sale" : "Add Sale" ?></h5>

                <form method="post" action="">

                    <!-- Hidden field to store ID for update -->
                    <input type="hidden" name="id" value="<?= $editData[0]['id'] ?? '' ?>">

                    <div class="row">

                        <!-- Team dropdown -->
                        <div class="col-md-4">
                            <select name="team" class="form-control mb-2" required>
                                <option value="">Select Team</option>

                                <?php if(isset($teams['error'])) { ?>
                                    <option disabled><?= $teams['error'] ?></option>

                                <?php } else { ?>
                                    <?php foreach($teams as $t) { ?>
                                        <option value="<?= $t['id'] ?>"
                                            <?= (isset($editData[0]['team_id']) && $editData[0]['team_id'] == $t['id']) ? "selected" : "" ?>>
                                            <?= $t['name'] ?>
                                        </option>
                                    <?php } ?>
                                <?php } ?>

                            </select>
                        </div>

                        <!-- Amount input -->
                        <div class="col-md-4">
                            <input type="number" step="0.01" name="amount" class="form-control mb-2"
                            placeholder="Amount"
                            value="<?= $editData[0]['amount'] ?? '' ?>" required>
                        </div>

                        <!-- Date input -->
                        <div class="col-md-4">
                            <input type="date" name="sale_date" class="form-control mb-2"
                            value="<?php
                                if (!empty($editData)) {
                                    $date = $editData['sale_date'] ?? ($editData[0]['sale_date'] ?? '');
                                    echo $date ? date('Y-m-d', strtotime($date)) : '';
                                }
                            ?>" required>
                        </div>
                    </div>

                    <!-- Submit button -->
                    <button type="submit" id="submitBtn" class="btn btn-primary">
                        <span id="btnText"><?= $editData ? "Update" : "Add" ?></span>
                        <span id="btnLoader" class="spinner-border spinner-border-sm d-none"></span>
                    </button>

                    <!-- Cancel button (only in edit mode) -->
                    <?php if($editData){ ?>
                        <a href="sales.php" class="btn btn-secondary">Cancel</a>
                    <?php } ?>
                </form>
            </div>

            <!-- ---------------------- TABLE ---------------------- -->
            <div class="card p-3 shadow">
                <h5>Sales List</h5>

                <table class="table table-bordered table-hover mt-3">

                    <!-- Table header -->
                    <thead class="table-dark">
                        <tr>
                            <th>Sl. No</th>
                            <th>Team</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th width="150">Action</th>
                        </tr>
                    </thead>

                    <!-- Table body -->
                    <tbody>

                        <!-- Loop through sales records -->
                        <?php $i=0; foreach($result as $row) { $i++; ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $row['team'] ?></td>
                            <td>$<?= $row['amount'] ?></td>
                            <td><?= $row['sale_date'] ?></td>
                            <td>
                                <a href="?edit=<?= $row['id'] ?>"  onclick="return handleEdit();" class="btn btn-warning btn-sm">Edit</a>
                                <a href="?delete=<?= $row['id'] ?>" onclick="return handleDelete(this);"  class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                        <?php } ?>
                     </tbody>

                 </table>
             </div>

         </div>
     </div>
 </div>

<!-- jQuery -->
<script src="assets/js/jquery-3.6.0.min.js"></script>
<!-- Full Page Loader -->
<div id="pageLoader" style="
    display:none;
    position:fixed;
    top:0; left:0;
    width:100%; height:100%;
    background:rgba(255,255,255,0.7);
    z-index:9999;
    text-align:center;
">
    <div style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%);">
        <div class="spinner-border text-primary"></div>
        <p class="mt-2">Processing...</p>
    </div>
</div>

<script>
function handleDelete(el){
    if(confirm('Delete this record?')){
        document.getElementById("pageLoader").style.display = "block";
        return true;
    }
    return false;
}

function handleEdit(){
    document.getElementById("pageLoader").style.display = "block";
    return true;
}
$(document).ready(function(){



    $("form").on("submit", function(){

        // Disable button
        $("#submitBtn").prop("disabled", true);

        // Show button loader
        $("#btnText").hide();
        $("#btnLoader").removeClass("d-none");

        // Show full page loader
        $("#pageLoader").show();
    });

});
</script>
</body>
</html>
