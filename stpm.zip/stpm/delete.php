<?php
include("config/db.php");

$id = $_GET['id'];

$query = "DELETE FROM sales WHERE id='$id'";
mysqli_query($conn, $query);

echo "<script>
        alert('Deleted Successfully');
        window.location='sales_manage.php';
      </script>";
?>